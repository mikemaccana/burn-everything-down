# Modern Workflow + Tooling

These are the slides to my talk - they might not make a ton of sense without the talk, but you are welcome to look at them. 

Built with Gulp, Jade, Stylus and Browsersync. Take a look! 

View at [wesbos.github.io/Modern-Workflow-and-Tooling-Talk](http://wesbos.github.io/Modern-Workflow-and-Tooling-Talk). Use your `←` and `→` keys to move through the slides. 
